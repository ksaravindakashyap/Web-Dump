# You Don't Know JS Yet: ES.Next & Beyond - 2nd Edition
# Foreword

| NOTE: |
| :--- |
| Work in progress |
