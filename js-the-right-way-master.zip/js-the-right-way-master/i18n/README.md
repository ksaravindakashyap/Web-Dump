# Do you want this project in your language?

### Feel free to contribute! :+1:


To translate this project to another language, you need to copy the ***default language directory*** and then translate it.
- en-us/ - Default language.

The **.json file is the main file of translation's structure**, be sure that this file have the **same name of your parent directory**.

The application will export the files in **'Public/language'** name-based on json filename.
