![](http://i.imgur.com/jaEbd80.png)

Feel free to contribute!

## Where?

<http://www.jstherightway.org>

## Why?

Today we have a bunch of websites running JavaScript. I think we need a place to put all the best practices and references together so we can share this (good) information and help keep the web more organized.

## Who?

[William Oliveira](http://github.com/gnuwilliam) - Open Source Developer

[Allan Esquina](http://github.com/allanesquina) - Open Source Developer

## License

[Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License](http://creativecommons.org/licenses/by-nc-sa/3.0/)

## Sponsor

[![GoBacklog](https://i.imgur.com/7lJBAXA.png)](https://gobacklog.com)
