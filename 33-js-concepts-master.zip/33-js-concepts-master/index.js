/* 
    33 JavaScript Concepts is a project created to help JavaScript developers master their skills. It is a compilation of fundamental JavaScript concepts that are important and fundamental. 

    This project was inspired by an article written by Stephen Curtis. 

    Any kind of contribution is welcome. Feel free to contribute.
*/
