---
name: New Example
about: A new example for wtfjs collection
title: ''
labels: new-example
assignees: ''

---

<!--
**New examples will be accepted only if they have an explanation.** Preferably, the explanation should contain links to the specification, blog posts, forum publications.

If you don't know why an example works the way it works, ask for help on [the discussion forum](https://github.com/denysdovhan/wtfjs/discussions).

Issues without explanations will be closed.
-->
