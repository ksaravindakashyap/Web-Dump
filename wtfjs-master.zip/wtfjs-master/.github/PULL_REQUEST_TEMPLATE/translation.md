<!-- 
**If you want a translation, please, make one.** Issues with translation requests will be closed in favor of PRs.

Before sending a PR with translation, please check if there are any existing PRs with translation to your language.

**You have to find someone who speaks your language natively to read, check and verify your translation.** That's how we are trying to prevent typos and mistakes.
-->
